/* dev-chat.js — Chat UI + Sessions + Commands + Typing + OpenAI/Local fallback */

(() => {
  // ====== Config ======
  const CONFIG = {
    storageKey: "db_ai_sessions_v5",
    backendUrl: null, // optional: "/api/chat" for server proxy
    systemPrompt: "You are a helpful assistant for Dragon Boating Developer Tools. Only answer about dev-login, teacher-login, send-emails-log, members-list, add-event, site-settings."
  };

  const $ = (id) => document.getElementById(id);
  const chatBox = $("chatBox");
  const userInput = $("userInput");
  const sendBtn = $("sendBtn");
  const newChatBtn = $("newChatBtn");
  const chatHistoryDiv = $("chatHistory");
  const clearBtn = $("clearBtn");
  const renameBtn = $("renameBtn");
  const sessionTitle = $("sessionTitle");

  let sessions = loadSessions();
  let currentSessionId = sessions.length ? sessions[sessions.length - 1].id : createSession("New chat");

  // ====== Storage ======
  function loadSessions() {
    try { return JSON.parse(localStorage.getItem(CONFIG.storageKey)) || []; }
    catch { return []; }
  }
  function saveSessions() { localStorage.setItem(CONFIG.storageKey, JSON.stringify(sessions)); }

  // ====== Session Helpers ======
  const uuid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
  const getSession = (id) => sessions.find(s => s.id === id);

  function createSession(title = "New chat") {
    const s = { id: uuid(), title, messages: [], createdAt: Date.now() };
    sessions.push(s);
    currentSessionId = s.id;
    saveSessions();
    renderSidebar();
    renderChat();
    return s.id;
  }

  function renameSession(id, newTitle) {
    const s = getSession(id);
    if (!s) return;
    s.title = newTitle || s.title;
    saveSessions();
    renderSidebar();
    renderChat();
  }

  function clearSession(id) {
    const s = getSession(id);
    if (!s) return;
    s.messages = [];
    saveSessions();
    renderChat();
  }

  // ====== Rendering ======
  function renderSidebar() {
    chatHistoryDiv.innerHTML = "";
    if (!sessions.length) {
      const empty = document.createElement("div");
      empty.className = "history-empty";
      empty.textContent = "No chats yet.";
      chatHistoryDiv.appendChild(empty);
      return;
    }
    sessions.forEach((s) => {
      const btn = document.createElement("button");
      btn.className = "history-item" + (s.id === currentSessionId ? " active" : "");
      btn.onclick = () => { currentSessionId = s.id; renderSidebar(); renderChat(); };

      const dot = document.createElement("div");
      dot.className = "session-dot";
      const title = document.createElement("div");
      title.className = "session-title";
      title.textContent = s.title || "Untitled";
      btn.appendChild(dot);
      btn.appendChild(title);
      chatHistoryDiv.appendChild(btn);
    });
  }

  function renderChat() {
    const s = getSession(currentSessionId);
    if (!s) return;
    sessionTitle.textContent = s.title || "Untitled";
    chatBox.innerHTML = "";
    s.messages.forEach(m => appendMessage(m.role, m.content, false));
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  function appendMessage(role, content, push = true) {
    const bubble = document.createElement("div");
    bubble.className = `message ${role === "user" ? "user" : "bot"}`;
    bubble.textContent = content;
    chatBox.appendChild(bubble);
    chatBox.scrollTop = chatBox.scrollHeight;

    if (push) {
      const s = getSession(currentSessionId);
      s.messages.push({ role, content, ts: Date.now() });
      if (s.messages.length === 1 && role === "user") {
        s.title = content.slice(0, 28) + (content.length > 28 ? "…" : "");
      }
      saveSessions();
      renderSidebar();
    }
  }

  function showTyping() {
    const wrap = document.createElement("div");
    wrap.className = "typing";
    for (let i = 0; i < 3; i++) {
      const dot = document.createElement("div");
      dot.className = "dot";
      wrap.appendChild(dot);
    }
    chatBox.appendChild(wrap);
    chatBox.scrollTop = chatBox.scrollHeight;
    return wrap;
  }

  function hideTyping(node) { if (node?.parentNode) node.parentNode.removeChild(node); }

  // ====== Commands ======
  function tryHandleCommand(text) {
    if (!text.startsWith("/")) return false;
    const [cmd, ...rest] = text.trim().split(" ");
    const arg = rest.join(" ");

    switch(cmd.toLowerCase()) {
      case "/goto": 
        if (arg) { appendMessage("assistant", `Opening ${arg}.html`); setTimeout(()=>window.location.href=`${arg}.html`,350); } 
        else appendMessage("assistant","Usage: /goto <page>"); 
        return true;

      case "/theme": 
        document.documentElement.classList.remove("light","coffee");
        if(arg==="light") document.documentElement.classList.add("light");
        else if(arg==="coffee") document.documentElement.classList.add("coffee");
        appendMessage("assistant", `Theme set to ${arg||"dark"}`);
        return true;

      case "/title": 
        if(arg) renameSession(currentSessionId,arg); 
        appendMessage("assistant", `Renamed chat to ${arg}`);
        return true;

      case "/clear": 
        clearSession(currentSessionId); 
        appendMessage("assistant", "Chat cleared");
        return true;

      default: 
        appendMessage("assistant", "Unknown command. Try /goto, /theme, /title, /clear");
        return true;
    }
  }

  // ====== AI ======
  async function getAIResponse(userText){
    // Backend proxy
    if(CONFIG.backendUrl){
      try{
        const res = await fetch(CONFIG.backendUrl,{
          method:"POST",
          headers:{"Content-Type":"application/json"},
          body:JSON.stringify({question:userText, system:CONFIG.systemPrompt, history:getSession(currentSessionId).messages})
        });
        if(res.ok){
          const data = await res.json();
          if(data.reply) return data.reply;
        }
      }catch{}
    }

    // Direct OpenAI key (DEV ONLY)
    const meta = document.querySelector('meta[name="openai-key"]');
    const OPENAI_API_KEY = meta?.content?.trim();
    if(OPENAI_API_KEY){
      try{
        const payload = {
          model:"gpt-3.5-turbo",
          messages:[{role:"system",content:CONFIG.systemPrompt}, ...getSession(currentSessionId).messages.map(m=>({role:m.role,content:m.content})), {role:"user",content:userText}],
          temperature:0.3
        };
        const r = await fetch("https://api.openai.com/v1/chat/completions",{
          method:"POST",
          headers:{"Content-Type":"application/json","Authorization":`Bearer ${OPENAI_API_KEY}`},
          body:JSON.stringify(payload)
        });
        const j = await r.json();
        const text = j?.choices?.[0]?.message?.content?.trim();
        if(text) return text;
      }catch{ console.error("OpenAI request failed"); }
    }

    // Local fallback
    return "I can help with dev-login, teacher-login, send-emails-log, members-list, add-event, site-settings.";
  }

  // ====== Send ======
  async function handleSend() {
    const text = userInput.value.trim();
    if (!text) return;

    if(tryHandleCommand(text)){
      userInput.value="";
      return;
    }

    appendMessage("user", text, true);
    userInput.value="";

    const typingNode = showTyping();
    let reply="";
    try { reply = await getAIResponse(text); } 
    catch { reply="⚠️ Error: Unable to get response."; }
    hideTyping(typingNode);
    appendMessage("assistant", reply, true);
  }

  function handleKey(e){
    if(e.key==="Enter" && !e.shiftKey){
      e.preventDefault();
      handleSend();
    }
  }

  // ====== Event Listeners ======
  sendBtn.addEventListener("click", handleSend);
  userInput.addEventListener("keydown", handleKey);
  newChatBtn.addEventListener("click",()=>createSession("New chat"));
  clearBtn.addEventListener("click",()=>clearSession(currentSessionId));
  renameBtn.addEventListener("click",()=>{
    const name = prompt("Rename chat:", getSession(currentSessionId)?.title || "Untitled");
    if(name?.trim()) renameSession(currentSessionId,name.trim());
  });

  // ====== Initial render ======
  renderSidebar();
  renderChat();

})();